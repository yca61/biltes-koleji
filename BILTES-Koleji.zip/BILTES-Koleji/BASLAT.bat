@echo off
chcp 65001 >nul
cd /d "%~dp0"
where node >nul 2>nul || (echo Node.js yuklu degil. https://nodejs.org adresinden LTS surumunu kurup tekrar calistirin. & pause & exit /b 1)
if not exist node_modules (call npm install || (pause & exit /b 1))
call npm run kur
pause
