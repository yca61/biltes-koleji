#!/bin/bash
cd "$(dirname "$0")"
command -v node >/dev/null || { echo "Node.js yüklü değil. https://nodejs.org adresinden LTS sürümünü kurun."; exit 1; }
[ -d node_modules ] || npm install || exit 1
npm run kur
