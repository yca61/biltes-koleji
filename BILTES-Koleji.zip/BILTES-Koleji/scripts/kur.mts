// Tek komutla yerel kurulum ve başlatma (Windows / macOS / Linux): npm run kur
// .env oluşturur, gömülü PostgreSQL'i başlatır, tabloları ve içeriği yükler, yönetici açar, derler ve siteyi çalıştırır.
import { spawn, spawnSync, type ChildProcess } from "node:child_process";
import { randomBytes } from "node:crypto";
import fs from "node:fs";
import net from "node:net";
import path from "node:path";

const node = process.execPath;
const bin = (p: string) => path.join(process.cwd(), "node_modules", p);
const dbPort = process.env.DEV_DB_PORT ?? "54329";
const port = process.env.PORT ?? "3000";
const log = (m: string) => console.log(`\n▶ ${m}`);

function loadEnv(): Record<string, string> {
  const o: Record<string, string> = {};
  if (!fs.existsSync(".env")) return o;
  for (const l of fs.readFileSync(".env", "utf8").split(/\r?\n/)) {
    const m = /^\s*([A-Z0-9_]+)\s*=\s*"?(.*?)"?\s*$/.exec(l);
    if (m) o[m[1]] = m[2];
  }
  return o;
}
function run(args: string[], env: Record<string, string> = {}) {
  const r = spawnSync(node, args, { stdio: "inherit", env: { ...process.env, ...loadEnv(), ...env } });
  if (r.status !== 0) { console.error(`\nHata: "${args.join(" ")}" başarısız oldu.`); process.exit(r.status ?? 1); }
}
const tsx = (script: string, env: Record<string, string> = {}) => run([bin("tsx/dist/cli.mjs"), script], env);

if (!fs.existsSync(".env")) {
  log(".env oluşturuluyor");
  fs.writeFileSync(".env", `DATABASE_URL="postgresql://biltes:biltes_dev_only@localhost:${dbPort}/biltes?schema=public"\nAUTH_SECRET="${randomBytes(48).toString("base64")}"\nSITE_URL="http://localhost:${port}"\n`);
}

log("Yerel veritabanı başlatılıyor");
const db: ChildProcess = spawn(node, [bin("tsx/dist/cli.mjs"), "scripts/dev-db.ts"], { stdio: "inherit", env: { ...process.env, DEV_DB_PORT: dbPort } });
const stopAll = () => { db.kill(); };
process.on("exit", stopAll);
process.on("SIGINT", () => { stopAll(); process.exit(0); });
let dbDead = false;
db.on("exit", () => { dbDead = true; });
const open = () => new Promise<boolean>((r) => { const s = net.connect(Number(dbPort), "127.0.0.1"); s.on("connect", () => { s.destroy(); r(true); }); s.on("error", () => r(false)); });
for (let i = 0; i < 120 && !(await open()); i++) {
  if (dbDead) { console.error(`Veritabanı başlamadı. ${dbPort} portu kullanımda olabilir.`); process.exit(1); }
  await new Promise((r) => setTimeout(r, 1000));
}
await new Promise((r) => setTimeout(r, 1500));

log("Tablolar hazırlanıyor");
run([bin("prisma/build/index.js"), "generate"]);
run([bin("prisma/build/index.js"), "db", "push", "--skip-generate"]);

log("Site içeriği yükleniyor");
tsx("scripts/import-data.mts");

const { PrismaClient } = await import("@prisma/client");
const client = new PrismaClient({ datasourceUrl: loadEnv().DATABASE_URL });
const pages = await client.page.count();
const media = await client.mediaAsset.count();
const hasAdmin = (await client.user.count()) > 0;
await client.$disconnect();
if (pages === 0) { console.error("\nHATA: Veritabanında sayfa yok, içerik yüklenemedi. Yukarıdaki mesajları kontrol edin."); process.exit(1); }
console.log(`İçerik hazır: ${pages} sayfa, ${media} görsel kaydı.`);
if (!fs.existsSync("public/uploads") || fs.readdirSync("public/uploads").length === 0) console.warn("UYARI: public/uploads klasörü boş veya yok; görseller görünmeyecek (zip tam çıkarılmamış olabilir).");
let adminLine = "";
if (!hasAdmin) {
  log("Yönetici hesabı oluşturuluyor");
  const email = process.env.ADMIN_EMAIL ?? "yonetici@biltes.local";
  const password = process.env.ADMIN_PASSWORD ?? `Biltes-${randomBytes(9).toString("base64url")}-${Math.floor(1000 + Math.random() * 9000)}`;
  tsx("scripts/create-admin.ts", { ADMIN_EMAIL: email, ADMIN_PASSWORD: password });
  adminLine = `  Yönetici girişi : http://localhost:${port}/admin\n  E-posta         : ${email}\n  Parola          : ${password}\n  (Parolayı bir yere not edin; panelden Kullanıcılar sayfasında değiştirebilirsiniz.)\n`;
}

if (!fs.existsSync(".next/BUILD_ID")) { log("Site derleniyor (birkaç dakika sürebilir)"); run([bin("next/dist/bin/next"), "build"]); }

console.log(`\n==========================================\n  BİLTES hazır: http://localhost:${port}/tr\n${adminLine}  Kapatmak için bu pencerede Ctrl+C\n==========================================`);
const web = spawn(node, [bin("next/dist/bin/next"), "start", "-p", port], { stdio: "inherit", env: { ...process.env, ...loadEnv() } });
web.on("exit", (c) => { stopAll(); process.exit(c ?? 0); });
