// Logo'dan favicon seti üretir: public/favicon.ico, icon-16/32/192/512.png, apple-touch-icon.png, site.webmanifest.
import sharp from "sharp";
import fs from "node:fs";
import path from "node:path";
const src = process.argv[2] ?? "public/uploads/canli-site/cropped-biltes-logo-1.png";
const out = (f: string) => path.join(process.cwd(), "public", f);
const trimmed = await sharp(src).trim().toBuffer();
const square = async (size: number, pad: number, bg?: string) => {
  const inner = Math.round(size * (1 - pad * 2));
  const logo = await sharp(trimmed).resize(inner, inner, { fit: "contain", background: { r: 0, g: 0, b: 0, alpha: 0 } }).toBuffer();
  return sharp({ create: { width: size, height: size, channels: 4, background: bg ?? { r: 0, g: 0, b: 0, alpha: 0 } } }).composite([{ input: logo, gravity: "center" }]).png().toBuffer();
};
const sizes: Record<string, [number, number, string?]> = { "icon-16.png": [16, 0.02], "icon-32.png": [32, 0.02], "icon-48.png": [48, 0.02], "icon-192.png": [192, 0.08, "#ffffff"], "icon-512.png": [512, 0.08, "#ffffff"], "apple-touch-icon.png": [180, 0.1, "#ffffff"] };
const bufs: Record<string, Buffer> = {};
for (const [f, [s, p, bg]] of Object.entries(sizes)) { bufs[f] = await square(s, p, bg); fs.writeFileSync(out(f), bufs[f]); }
// ICO: PNG gömülü 16/32/48
const ico = [bufs["icon-16.png"], bufs["icon-32.png"], bufs["icon-48.png"]];
const head = Buffer.alloc(6); head.writeUInt16LE(0, 0); head.writeUInt16LE(1, 2); head.writeUInt16LE(ico.length, 4);
let offset = 6 + 16 * ico.length;
const dir = ico.map((b, i) => { const e = Buffer.alloc(16); const s = [16, 32, 48][i]; e[0] = s; e[1] = s; e.writeUInt16LE(1, 4); e.writeUInt16LE(32, 6); e.writeUInt32LE(b.length, 8); e.writeUInt32LE(offset, 12); offset += b.length; return e; });
fs.writeFileSync(out("favicon.ico"), Buffer.concat([head, ...dir, ...ico]));
fs.writeFileSync(out("site.webmanifest"), JSON.stringify({ name: "BİLTES Koleji", short_name: "BİLTES", start_url: "/tr", display: "standalone", background_color: "#ffffff", theme_color: "#1B3A78", icons: [{ src: "/icon-192.png", sizes: "192x192", type: "image/png" }, { src: "/icon-512.png", sizes: "512x512", type: "image/png" }] }, null, 2));
console.log("favicon seti yazıldı");
