// data/icerik.json içeriğini boş bir veritabanına yükler (yalnızca tablolar boşsa).
import { Prisma, PrismaClient } from "@prisma/client";
import fs from "node:fs";

const file = "data/icerik.json";
if (!fs.existsSync(file)) { console.error("HATA: data/icerik.json bulunamadı (zip eksik çıkarılmış olabilir). İçerik yüklenemedi."); process.exit(1); }
const db = new PrismaClient();
if ((await db.page.count()) > 0) { console.log("Veritabanında içerik var; yükleme atlandı."); await db.$disconnect(); process.exit(0); }
const data = JSON.parse(fs.readFileSync(file, "utf8")) as Record<string, Record<string, unknown>[]>;
const models = Prisma.dmmf.datamodel.models;
const names = new Set(models.map((m) => m.name));
await db.$transaction(async (tx) => {
  await tx.$executeRawUnsafe("SET LOCAL session_replication_role = replica");
  for (const m of models) {
    const rows = data[m.name];
    if (!rows?.length) continue;
    const dates = m.fields.filter((f) => f.type === "DateTime").map((f) => f.name);
    // Dışarıda bırakılan tablolara (örn. User) işaret eden isteğe bağlı alanları boşalt.
    const dangling = m.fields.filter((f) => f.relationName && (!(f.type in data) && names.has(f.type)) && f.relationFromFields?.length).flatMap((f) => f.relationFromFields!);
    const fixed = rows.map((r) => {
      const o = { ...r };
      for (const d of dates) if (o[d]) o[d] = new Date(o[d] as string);
      for (const d of dangling) o[d] = null;
      return o;
    });
    const key = m.name.charAt(0).toLowerCase() + m.name.slice(1);
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    await (tx as any)[key].createMany({ data: fixed });
    console.log(`${m.name}: ${fixed.length}`);
  }
}, { timeout: 120000 });
await db.$disconnect();
console.log("İçerik yüklendi.");
