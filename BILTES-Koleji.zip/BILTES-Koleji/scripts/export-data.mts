// Site içeriğini (sayfalar, ayarlar, menüler, görsel kayıtları…) data/icerik.json dosyasına yazar.
// Kullanıcı hesapları, oturumlar, başvurular (kişisel veri) ve denetim kayıtları DIŞARIDA bırakılır.
import { Prisma, PrismaClient } from "@prisma/client";
import fs from "node:fs";

const SKIP = new Set(["User", "Session", "PasswordReset", "RateLimit", "Lead", "LeadNote", "LeadEvent", "AuditLog", "PageRevision"]);
const db = new PrismaClient();
const out: Record<string, unknown[]> = {};
for (const m of Prisma.dmmf.datamodel.models) {
  if (SKIP.has(m.name)) continue;
  const key = m.name.charAt(0).toLowerCase() + m.name.slice(1);
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  out[m.name] = await (db as any)[key].findMany();
  console.log(m.name, out[m.name].length);
}
fs.mkdirSync("data", { recursive: true });
fs.writeFileSync("data/icerik.json", JSON.stringify(out));
await db.$disconnect();
