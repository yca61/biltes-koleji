import type { MetadataRoute } from "next";
import { siteUrl } from "@/lib/utils";
import { getSettings } from "@/lib/settings";

export const dynamic = "force-dynamic";
export default async function robots(): Promise<MetadataRoute.Robots> {
  const { seo } = await getSettings();
  if (seo.noindex) return { rules: [{ userAgent: "*", disallow: "/" }] };
  return { rules: [{ userAgent: "*", allow: "/", disallow: ["/admin", "/api"] }], sitemap: `${siteUrl()}/sitemap.xml`, host: siteUrl() };
}
