import Link from "next/link";
import { ArrowUpRight, CheckCircle2, AlertTriangle, Info, Newspaper, FileText, Home, Image as Img, Layers, Menu as MenuIcon, Inbox, Eye, FileClock, ImageIcon, Plus } from "lucide-react";
import { db } from "@/lib/db";
import { requireUser } from "@/lib/auth";
import { can, STATUS_LABEL } from "@/lib/permissions";
import { tx } from "@/lib/i18n";
import { getSettings } from "@/lib/settings";
import { mailConfigured } from "@/lib/mail";
import { storageMode } from "@/lib/storage";

const ACTION: Record<string, string> = { create: "oluşturdu", update: "güncelledi", delete: "sildi", login: "giriş yaptı", logout: "çıkış yaptı", publish: "yayınladı", visibility: "görünürlüğü değiştirdi", reorder: "sırayı değiştirdi", export: "dışa aktardı" };
const ENTITY: Record<string, string> = { hero: "hero slaytını", home: "anasayfa bölümünü", page: "sayfayı", pages: "sayfayı", news: "haberi", campus: "kampüsü", campuses: "kampüsü", program: "programı", settings: "ayarları", media: "medyayı", menu: "menüyü", user: "kullanıcıyı", lead: "başvuruyu" };
const LEAD_COLOR: Record<string, string> = { NEW: "bg-[#D93A17]", CONTACTED: "bg-amber", APPOINTMENT: "bg-teal", MET: "bg-navy", ENROLLING: "bg-emerald-600", CLOSED: "bg-ink/30" };

function ago(d: Date) {
  const m = Math.round((Date.now() - d.getTime()) / 60000);
  if (m < 1) return "az önce"; if (m < 60) return `${m} dk önce`; const h = Math.round(m / 60); if (h < 24) return `${h} sa önce`; return d.toLocaleDateString("tr-TR", { day: "numeric", month: "short" });
}

export default async function Dashboard() {
  const u = await requireUser();
  const leadsOn = can(u.role, "leads.view"), content = can(u.role, "content"), mediaOn = can(u.role, "media"), settingsOn = can(u.role, "settings");
  const s = await getSettings();
  const [leadGroups, leads, draftNews, pubNews, pages, media, audits, heroCount] = await Promise.all([
    leadsOn ? db.lead.groupBy({ by: ["status"], _count: true }) : [],
    leadsOn ? db.lead.findMany({ orderBy: { createdAt: "desc" }, take: 5, include: { campus: true } }) : [],
    content ? db.newsArticle.count({ where: { OR: [{ status: "DRAFT" }, { status: "PUBLISHED", publishAt: { gt: new Date() } }] } }) : 0,
    content ? db.newsArticle.count({ where: { status: "PUBLISHED" } }) : 0,
    content ? db.page.findMany({ where: { status: "PUBLISHED" }, select: { group: true, slug: true, title: true, blocks: true } }) : [],
    mediaOn ? db.mediaAsset.findMany({ select: { alt: true, kind: true } }) : [],
    content ? db.auditLog.findMany({ orderBy: { createdAt: "desc" }, take: 7, include: { user: { select: { name: true } } } }) : [],
    content ? db.heroSlide.count() : 0,
  ]);
  const leadTotal = leadGroups.reduce((a, g) => a + g._count, 0);
  const leadNew = leadGroups.find((g) => g.status === "NEW")?._count ?? 0;
  const blocks = (p: { blocks: unknown }) => p.blocks as { tr?: unknown[]; en?: unknown[] };
  const emptyPages = pages.filter((p) => !(blocks(p).tr?.length));
  const noEn = pages.filter((p) => blocks(p).tr?.length && !blocks(p).en?.length);
  const noAlt = media.filter((m) => m.kind === "image" && !tx(m.alt, "tr")).length;
  const legalLive = ["kvkk-aydinlatma-metni", "gizlilik-politikasi", "cerez-tercihleri", "kullanim-kosullari"].filter((slug) => pages.some((p) => p.group === "yasal" && p.slug === slug && blocks(p).tr?.length)).length;
  const company = Object.values(s.company ?? {}).some(Boolean);

  type Check = { ok: boolean | "info"; label: string; hint: string; href?: string };
  const checks: Check[] = [
    { ok: !!s.logoUrl, label: "Logo", hint: s.logoUrl ? "Yüklü" : "Henüz yüklenmedi", href: "/admin/ayarlar" },
    { ok: !!s.contact.address, label: "İletişim adresi", hint: s.contact.address ? "Girildi" : "Adres alanı boş", href: "/admin/ayarlar" },
    { ok: company, label: "Resmî kurum bilgileri", hint: company ? "Girildi" : "Ticari unvan, MERSİS, MEB kurum kodu vb. girilmedi", href: "/admin/ayarlar" },
    { ok: mailConfigured(), label: "E-posta (SMTP)", hint: mailConfigured() ? "Yapılandırıldı" : "Yapılandırılmadı: şifre sıfırlama ve başvuru bildirimleri gönderilemez" },
    { ok: storageMode() === "s3", label: "Dosya depolama", hint: storageMode() === "s3" ? "Bulut depolama (S3) etkin" : storageMode() === "local" ? "Yerel depolama (yalnızca geliştirme). Canlıda S3 uyumlu depolama gerekir" : "Yapılandırılmadı: yükleme yapılamaz" },
    { ok: !!s.gaId ? true : "info", label: "Analitik (Google Analytics)", hint: s.gaId ? "Etkin, yalnızca çerez onayıyla çalışır" : "Tanımlı değil (isteğe bağlı)", href: "/admin/ayarlar" },
    { ok: legalLive === 4, label: "Yasal metinler", hint: `${legalLive}/4 sayfa yayında. Yayından önce hukuk danışmanı onayı gerekir`, href: "/admin/r/pages?q=yasal" },
    { ok: heroCount > 0, label: "Hero slaytları", hint: `${heroCount} slayt`, href: "/admin/r/hero" },
  ];
  const done = checks.filter((c) => c.ok === true).length;

  const alerts: { icon: typeof Info; text: string; href: string }[] = [];
  if (emptyPages.length) alerts.push({ icon: FileText, text: `${emptyPages.length} yayındaki sayfanın içeriği boş`, href: "/admin/r/pages" });
  if (noEn.length) alerts.push({ icon: FileClock, text: `${noEn.length} sayfanın İngilizce çevirisi yok`, href: "/admin/r/pages" });
  if (noAlt) alerts.push({ icon: ImageIcon, text: `${noAlt} görselin alt metni (erişilebilirlik) eksik`, href: "/admin/medya" });
  if (draftNews) alerts.push({ icon: Newspaper, text: `${draftNews} haber taslak veya zamanlanmış`, href: "/admin/r/news?durum=DRAFT" });

  const quick = [
    content && { href: "/admin/r/news/yeni", label: "Yeni haber", icon: Newspaper },
    content && { href: "/admin/r/pages/yeni", label: "Yeni sayfa", icon: FileText },
    content && { href: "/admin/anasayfa", label: "Anasayfayı düzenle", icon: Home },
    content && { href: "/admin/r/hero", label: "Hero slaytları", icon: Layers },
    mediaOn && { href: "/admin/medya", label: "Medya yükle", icon: Img },
    can(u.role, "menus") && { href: "/admin/menuler", label: "Menüler", icon: MenuIcon },
  ].filter(Boolean) as { href: string; label: string; icon: typeof Home }[];

  const hour = Number(new Date().toLocaleString("tr-TR", { hour: "numeric", hour12: false, timeZone: "Europe/Istanbul" }));
  const greet = hour < 6 ? "İyi geceler" : hour < 12 ? "Günaydın" : hour < 18 ? "İyi günler" : "İyi akşamlar";
  const Stat = ({ l, v, href, icon: Icon, tone }: { l: string; v: number; href?: string; icon: typeof Eye; tone: string }) => {
    const c = (
      <div className="group flex h-full flex-col items-start gap-3 rounded-2xl border border-navy/10 bg-white p-4 shadow-sm sm:flex-row sm:items-center sm:gap-4 sm:p-5 transition hover:-translate-y-0.5 hover:shadow-md">
        <span className={`grid size-11 shrink-0 place-items-center rounded-xl sm:size-12 ${tone}`}><Icon size={21} /></span>
        <div><p className="font-display text-3xl font-extrabold leading-none text-navy">{v}</p><p className="mt-1.5 text-xs font-medium text-ink/60">{l}</p></div>
      </div>
    );
    return href ? <Link href={href} className="block">{c}</Link> : c;
  };

  return (
    <div className="space-y-8">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div><h1 className="font-display text-3xl font-extrabold text-navy">{greet}, {u.name.split(" ")[0]}</h1>
          <p className="mt-1 text-sm text-ink/60">{new Date().toLocaleDateString("tr-TR", { dateStyle: "full", timeZone: "Europe/Istanbul" })} · BİLTES Koleji yönetim paneli</p></div>
        <div className="flex flex-wrap gap-2">{quick.map((q) => <Link key={q.href} href={q.href} className="inline-flex items-center gap-2 rounded-full border border-navy/15 bg-white px-4 py-2 text-sm font-medium text-navy shadow-sm transition hover:border-teal hover:text-teal"><q.icon size={15} />{q.label}</Link>)}</div>
      </div>

      <div className="grid grid-cols-2 gap-3 sm:gap-4 lg:grid-cols-3 2xl:grid-cols-5">
        {leadsOn && <Stat l="Yeni başvuru" v={leadNew} href="/admin/leads?status=NEW" icon={Inbox} tone="bg-[#D93A17]/10 text-[#D93A17]" />}
        {leadsOn && <Stat l="Toplam başvuru" v={leadTotal} href="/admin/leads" icon={Inbox} tone="bg-navy/10 text-navy" />}
        {content && <Stat l="Yayındaki sayfa" v={pages.length} href="/admin/r/pages" icon={FileText} tone="bg-teal/10 text-teal" />}
        {content && <Stat l="Yayındaki haber" v={pubNews} href="/admin/r/news" icon={Newspaper} tone="bg-amber/25 text-navy" />}
        {mediaOn && <Stat l="Medya dosyası" v={media.length} href="/admin/medya" icon={Img} tone="bg-navy/10 text-navy" />}
      </div>

      <div className="grid gap-6 xl:grid-cols-3">
        {settingsOn || content ? (
          <section className="rounded-2xl border border-navy/10 bg-white p-6 shadow-sm xl:col-span-2">
            <div className="flex items-center justify-between"><h2 className="font-display text-lg font-bold text-navy">Yayına hazırlık</h2><span className="text-sm font-semibold text-teal">{done}/{checks.length} tamam</span></div>
            <div className="mt-3 h-2 overflow-hidden rounded-full bg-navy/10"><div className="h-full rounded-full bg-teal transition-all" style={{ width: `${(done / checks.length) * 100}%` }} /></div>
            <ul className="mt-5 grid gap-x-8 gap-y-1 md:grid-cols-2">
              {checks.map((c) => {
                const Icon = c.ok === true ? CheckCircle2 : c.ok === "info" ? Info : AlertTriangle;
                const row = (
                  <div className="flex items-start gap-3 py-2.5">
                    <Icon size={18} className={`mt-0.5 shrink-0 ${c.ok === true ? "text-emerald-600" : c.ok === "info" ? "text-ink/40" : "text-[#D93A17]"}`} />
                    <div className="min-w-0"><p className="text-sm font-semibold text-navy">{c.label}</p><p className="text-xs leading-5 text-ink/60">{c.hint}</p></div>
                  </div>
                );
                return <li key={c.label} className="border-b border-navy/5">{c.href && c.ok !== true ? <Link href={c.href} className="block rounded-lg transition hover:bg-mist">{row}</Link> : row}</li>;
              })}
            </ul>
          </section>
        ) : null}
        <div className="space-y-6">
          {alerts.length > 0 && (
            <section className="rounded-2xl border border-amber/50 bg-amber/10 p-6">
              <h2 className="font-display text-lg font-bold text-navy">Dikkat edilecekler</h2>
              <ul className="mt-3 space-y-1">{alerts.map((a) => <li key={a.text}><Link href={a.href} className="flex items-center gap-3 rounded-lg px-2 py-2 text-sm text-navy transition hover:bg-white/70"><a.icon size={16} className="shrink-0 text-navy/60" /><span className="flex-1">{a.text}</span><ArrowUpRight size={14} className="text-navy/40" /></Link></li>)}</ul>
            </section>
          )}
          {leadsOn && leadTotal > 0 && (
            <section className="rounded-2xl border border-navy/10 bg-white p-6 shadow-sm">
              <h2 className="font-display text-lg font-bold text-navy">Başvuru durumları</h2>
              <ul className="mt-4 space-y-3">{Object.entries(STATUS_LABEL).map(([k, label]) => { const n = leadGroups.find((g) => g.status === k)?._count ?? 0; return (
                <li key={k}><div className="flex justify-between text-xs"><span className="text-ink/70">{label}</span><b className="text-navy">{n}</b></div><div className="mt-1 h-1.5 rounded-full bg-navy/10"><div className={`h-full rounded-full ${LEAD_COLOR[k]}`} style={{ width: `${(n / leadTotal) * 100}%` }} /></div></li>); })}</ul>
            </section>
          )}
        </div>
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        {leadsOn && (
          <section className="rounded-2xl border border-navy/10 bg-white p-6 shadow-sm">
            <div className="flex items-center justify-between"><h2 className="font-display text-lg font-bold text-navy">Son başvurular</h2><Link href="/admin/leads" className="text-sm font-medium text-teal hover:underline">Tümü</Link></div>
            <ul className="mt-3 divide-y divide-navy/5 text-sm">
              {leads.map((l) => <li key={l.id}><Link href={`/admin/leads/${l.id}`} className="flex items-center justify-between gap-3 py-3 transition hover:text-teal"><span><b className="font-semibold text-navy">{l.parentName}</b><span className="block text-xs text-ink/55">{l.campus?.name ?? "Kampüs seçilmedi"} · {ago(l.createdAt)}</span></span><span className="shrink-0 rounded-full bg-navy/5 px-3 py-1 text-xs font-medium text-navy">{STATUS_LABEL[l.status]}</span></Link></li>)}
              {!leads.length && <li className="py-10 text-center text-ink/50">Henüz başvuru yok. Başvuru formları sitede yayında; gelenler burada görünür.</li>}
            </ul>
          </section>
        )}
        {content && (
          <section className="rounded-2xl border border-navy/10 bg-white p-6 shadow-sm">
            <div className="flex items-center justify-between"><h2 className="font-display text-lg font-bold text-navy">Son işlemler</h2>{can(u.role, "audit") && <Link href="/admin/denetim" className="text-sm font-medium text-teal hover:underline">Tümü</Link>}</div>
            <ul className="mt-3 divide-y divide-navy/5 text-sm">
              {audits.map((a) => <li key={a.id} className="flex items-start justify-between gap-3 py-3"><span className="min-w-0"><b className="font-semibold text-navy">{a.user?.name ?? "Sistem"}</b> <span className="text-ink/70">{(ENTITY[a.entity ?? ""] ?? (a.entity ? a.entity + " kaydını" : "")) + " " + (ACTION[a.action] ?? a.action)}</span>{a.detail && <span className="block truncate text-xs text-ink/50">{tx(a.detail, "tr")}</span>}</span><span className="shrink-0 text-xs text-ink/45">{ago(a.createdAt)}</span></li>)}
            </ul>
          </section>
        )}
      </div>
    </div>
  );
}
