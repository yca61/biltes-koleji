import Link from "next/link";
import { CheckCircle2, AlertTriangle, Info, ExternalLink, Globe, FileSearch, Bot, ShieldCheck, ImageIcon, Languages } from "lucide-react";
import { db } from "@/lib/db";
import { requirePermission } from "@/lib/auth";
import { getSettings } from "@/lib/settings";
import { siteUrl } from "@/lib/utils";

type Item = { type: string; title: string; path: string; edit: string; seoTitle: string; seoDesc: string; effTitle: string; effDesc: string; ogImage: boolean; en: boolean; draft: boolean };
const j = (v: unknown, l: "tr" | "en") => (v && typeof v === "object" ? (((v as Record<string, unknown>)[l] as string) ?? "") : typeof v === "string" ? v : "");

function issues(i: Item, dupes: Set<string>) {
  const out: { t: string; sev: "bad" | "warn" }[] = [];
  const tl = i.effTitle.length, dl = i.effDesc.length;
  if (!i.seoTitle && !i.title) out.push({ t: "Başlık yok", sev: "bad" });
  if (tl > 60) out.push({ t: `Başlık uzun (${tl})`, sev: "warn" });
  if (!i.effDesc) out.push({ t: "Açıklama yok", sev: "bad" });
  else if (dl < 70) out.push({ t: `Açıklama kısa (${dl})`, sev: "warn" });
  else if (dl > 160) out.push({ t: `Açıklama uzun (${dl})`, sev: "warn" });
  if (!i.ogImage) out.push({ t: "Paylaşım görseli yok", sev: "warn" });
  if (!i.en) out.push({ t: "İngilizce yok", sev: "warn" });
  if (dupes.has(i.effTitle.toLocaleLowerCase("tr"))) out.push({ t: "Başlık tekrarı", sev: "warn" });
  return out;
}

export default async function SeoPage({ searchParams }: { searchParams: Promise<{ f?: string }> }) {
  await requirePermission("content");
  const f = (await searchParams).f ?? "";
  const s = await getSettings();
  const base = siteUrl();
  const [pages, news, campuses, programs, events] = await Promise.all([
    db.page.findMany({ where: { status: "PUBLISHED" }, select: { id: true, group: true, slug: true, title: true, summary: true, seo: true, coverId: true, blocks: true } }),
    db.newsArticle.findMany({ where: { status: "PUBLISHED" }, select: { id: true, slug: true, title: true, excerpt: true, seo: true, coverId: true, body: true } }),
    db.campus.findMany({ where: { status: "PUBLISHED" }, select: { id: true, slug: true, name: true, description: true, seo: true, mainImageId: true } }),
    db.educationProgram.findMany({ where: { status: "PUBLISHED" }, select: { id: true, slug: true, title: true, summary: true, seo: true, imageId: true, body: true } }),
    db.event.findMany({ where: { status: "PUBLISHED" }, select: { id: true, slug: true, title: true, description: true, seo: true, imageId: true } }),
  ]);
  const seo = (v: unknown) => (v ?? {}) as { title?: unknown; description?: unknown; ogImage?: string; noindex?: boolean };
  const hidden = pages.filter((p) => seo(p.seo).noindex).length;
  const items: Item[] = [
    { type: "Ana sayfa", title: s.siteTitle, path: "/", edit: "/admin/ayarlar", seoTitle: s.siteTitle, seoDesc: s.siteDescription, effTitle: s.siteTitle, effDesc: s.siteDescription, ogImage: !!s.seo.defaultOgImage, en: true, draft: false },
    ...pages.filter((p) => !seo(p.seo).noindex).map((p): Item => { const b = p.blocks as { en?: unknown[] }; const x = seo(p.seo); const t = j(p.title, "tr"); return { type: "Sayfa", title: t, path: `/${p.group}/${p.slug}`, edit: `/admin/r/pages/${p.id}`, seoTitle: j(x.title, "tr"), seoDesc: j(x.description, "tr"), effTitle: j(x.title, "tr") || t, effDesc: j(x.description, "tr") || j(p.summary, "tr"), ogImage: !!(x.ogImage || p.coverId || s.seo.defaultOgImage), en: !!b.en?.length, draft: false }; }),
    ...news.map((n): Item => { const x = seo(n.seo); const t = j(n.title, "tr"); const b = n.body as { en?: string } | null; return { type: "Haber", title: t, path: `/haberler/${n.slug}`, edit: `/admin/r/news/${n.id}`, seoTitle: j(x.title, "tr"), seoDesc: j(x.description, "tr"), effTitle: j(x.title, "tr") || t, effDesc: j(x.description, "tr") || j(n.excerpt, "tr"), ogImage: !!(x.ogImage || n.coverId || s.seo.defaultOgImage), en: !!b?.en, draft: false }; }),
    ...campuses.map((c): Item => { const x = seo(c.seo); return { type: "Kampüs", title: c.name, path: `/kampusler/${c.slug}`, edit: `/admin/r/campuses/${c.id}`, seoTitle: j(x.title, "tr"), seoDesc: j(x.description, "tr"), effTitle: j(x.title, "tr") || c.name, effDesc: j(x.description, "tr") || j(c.description, "tr"), ogImage: !!(x.ogImage || c.mainImageId || s.seo.defaultOgImage), en: !!j(c.description, "en"), draft: false }; }),
    ...programs.map((p): Item => { const x = seo(p.seo); const t = j(p.title, "tr"); const b = p.body as { en?: unknown[] } | null; return { type: "Program", title: t, path: `/egitim/${p.slug}`, edit: `/admin/r/programs/${p.id}`, seoTitle: j(x.title, "tr"), seoDesc: j(x.description, "tr"), effTitle: j(x.title, "tr") || t, effDesc: j(x.description, "tr") || j(p.summary, "tr"), ogImage: !!(x.ogImage || p.imageId || s.seo.defaultOgImage), en: !!b?.en?.length, draft: false }; }),
    ...events.map((e): Item => { const x = seo(e.seo); const t = j(e.title, "tr"); return { type: "Etkinlik", title: t, path: `/etkinlikler/${e.slug}`, edit: `/admin/r/events/${e.id}`, seoTitle: j(x.title, "tr"), seoDesc: j(x.description, "tr"), effTitle: j(x.title, "tr") || t, effDesc: j(x.description, "tr") || j(e.description, "tr"), ogImage: !!(x.ogImage || e.imageId || s.seo.defaultOgImage), en: !!j(e.description, "en"), draft: false }; }),
  ];
  const count: Record<string, number> = {};
  for (const i of items) { const k = i.effTitle.toLocaleLowerCase("tr"); count[k] = (count[k] ?? 0) + 1; }
  const dupes = new Set(Object.entries(count).filter(([, n]) => n > 1).map(([k]) => k));
  const scored = items.map((i) => { const is = issues(i, dupes); const score = Math.max(0, 100 - is.reduce((a, x) => a + (x.sev === "bad" ? 25 : 8), 0)); return { ...i, is, score }; }).sort((a, b) => a.score - b.score);
  const avg = scored.length ? Math.round(scored.reduce((a, x) => a + x.score, 0) / scored.length) : 0;
  const withIssues = scored.filter((x) => x.is.length), clean = scored.filter((x) => !x.is.length);
  const shown = f === "sorunlu" ? withIssues : f === "sorunsuz" ? clean : scored;
  const noDesc = scored.filter((x) => !x.effDesc).length, noOg = scored.filter((x) => !x.ogImage).length, noEn = scored.filter((x) => !x.en).length;
  const local = /localhost|127\.0\.0\.1/.test(base);

  type Check = { ok: boolean | "info"; label: string; hint: string; href?: string };
  const checks: Check[] = [
    { ok: !s.seo.noindex, label: "Arama motorlarına açık", hint: s.seo.noindex ? "Site gizli (noindex). Google siteyi listelemez. Yayına alırken kapatın" : "Evet, sayfalar dizinlenebilir", href: "/admin/ayarlar" },
    { ok: !local, label: "Gerçek alan adı (SITE_URL)", hint: local ? `Şu an ${base}. Canlıda SITE_URL ortam değişkeni sitenin gerçek adresi olmalı; sitemap ve canonical buna göre üretilir` : base },
    { ok: !!s.seo.googleVerification, label: "Google Search Console doğrulaması", hint: s.seo.googleVerification ? "Doğrulama kodu girildi" : "Kod girilmedi. Search Console'da siteyi ekleyip kodu Site Ayarları → SEO'ya yapıştırın", href: "/admin/ayarlar" },
    { ok: !!s.seo.defaultOgImage, label: "Varsayılan paylaşım görseli", hint: s.seo.defaultOgImage ? "Yüklü" : "Yok. Görseli olmayan sayfalar WhatsApp/Google'da görselsiz paylaşılır", href: "/admin/ayarlar" },
    { ok: true, label: "Sitemap, robots.txt, hreflang, canonical", hint: `Otomatik üretiliyor · ${scored.length * 2 + 10} adres (TR+EN)` },
    { ok: true, label: "Yapılandırılmış veri (JSON-LD)", hint: "Kurum (School), kampüs ve haber sayfalarında otomatik" },
  ];
  const okN = checks.filter((c) => c.ok === true).length;

  const Pill = ({ t, sev }: { t: string; sev: "bad" | "warn" }) => <span className={`rounded-full px-2.5 py-1 text-[11px] font-semibold ${sev === "bad" ? "bg-[#D93A17]/10 text-[#D93A17]" : "bg-amber/30 text-navy"}`}>{t}</span>;
  const tone = avg >= 80 ? "text-emerald-600" : avg >= 60 ? "text-amber" : "text-[#D93A17]";
  const tools = [
    { label: "Google Search Console", href: "https://search.google.com/search-console", note: "Siteyi ekleyin ve sitemap gönderin" },
    { label: "PageSpeed Insights", href: `https://pagespeed.web.dev/analysis?url=${encodeURIComponent(base + "/tr")}`, note: "Hız ve Core Web Vitals" },
    { label: "Zengin sonuç testi", href: `https://search.google.com/test/rich-results?url=${encodeURIComponent(base + "/tr")}`, note: "Yapılandırılmış veri kontrolü" },
    { label: "Mobil uyumluluk", href: `https://pagespeed.web.dev/analysis?url=${encodeURIComponent(base + "/tr")}&form_factor=mobile`, note: "Mobil görünüm raporu" },
  ];

  return (
    <div className="space-y-8">
      <div><h1 className="font-display text-2xl font-extrabold text-navy">Google SEO</h1><p className="text-sm text-ink/55">Sitenin arama sonuçlarında nasıl göründüğünü kontrol edin ve eksikleri tamamlayın.</p></div>

      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <div className="rounded-2xl border border-navy/10 bg-white p-5 shadow-sm"><p className="text-xs font-medium text-ink/60">Ortalama SEO puanı</p><p className={`mt-2 font-display text-4xl font-extrabold ${tone}`}>{avg}<span className="text-lg text-ink/40">/100</span></p><p className="mt-1 text-xs text-ink/50">{scored.length} sayfa denetlendi{hidden ? ` · ${hidden} sayfa noindex` : ""}</p></div>
        {[{ l: "Açıklaması eksik", v: noDesc, i: FileSearch }, { l: "Paylaşım görseli yok", v: noOg, i: ImageIcon }, { l: "İngilizcesi yok", v: noEn, i: Languages }].map((x) => (
          <div key={x.l} className="flex items-center gap-4 rounded-2xl border border-navy/10 bg-white p-5 shadow-sm"><span className="grid size-12 place-items-center rounded-xl bg-navy/10 text-navy"><x.i size={22} /></span><div><p className="font-display text-3xl font-extrabold leading-none text-navy">{x.v}</p><p className="mt-1.5 text-xs font-medium text-ink/60">{x.l}</p></div></div>
        ))}
      </div>

      <div className="grid gap-6 xl:grid-cols-3">
        <section className="rounded-2xl border border-navy/10 bg-white p-6 shadow-sm xl:col-span-2">
          <div className="flex items-center justify-between"><h2 className="font-display text-lg font-bold text-navy">Site geneli kontroller</h2><span className="text-sm font-semibold text-teal">{okN}/{checks.length} tamam</span></div>
          <ul className="mt-4 grid gap-x-8 md:grid-cols-2">
            {checks.map((c) => {
              const I = c.ok === true ? CheckCircle2 : c.ok === "info" ? Info : AlertTriangle;
              const row = <div className="flex items-start gap-3 py-2.5"><I size={18} className={`mt-0.5 shrink-0 ${c.ok === true ? "text-emerald-600" : "text-[#D93A17]"}`} /><div className="min-w-0"><p className="text-sm font-semibold text-navy">{c.label}</p><p className="text-xs leading-5 text-ink/60">{c.hint}</p></div></div>;
              return <li key={c.label} className="border-b border-navy/5">{c.href && c.ok !== true ? <Link href={c.href} className="block rounded-lg transition hover:bg-mist">{row}</Link> : row}</li>;
            })}
          </ul>
          <div className="mt-5 flex flex-wrap gap-3 text-sm">
            <a href="/sitemap.xml" target="_blank" className="inline-flex items-center gap-2 rounded-full border border-navy/15 px-4 py-2 text-navy hover:bg-navy hover:text-white"><Globe size={14} />sitemap.xml</a>
            <a href="/robots.txt" target="_blank" className="inline-flex items-center gap-2 rounded-full border border-navy/15 px-4 py-2 text-navy hover:bg-navy hover:text-white"><Bot size={14} />robots.txt</a>
            <Link href="/admin/ayarlar" className="inline-flex items-center gap-2 rounded-full bg-teal px-4 py-2 font-semibold text-white hover:bg-navy"><ShieldCheck size={14} />SEO ayarları</Link>
          </div>
        </section>
        <section className="rounded-2xl border border-navy/10 bg-white p-6 shadow-sm">
          <h2 className="font-display text-lg font-bold text-navy">Google araçları</h2>
          <ul className="mt-3 space-y-1">{tools.map((t) => <li key={t.label}><a href={t.href} target="_blank" rel="noopener noreferrer" className="flex items-center justify-between gap-3 rounded-lg px-2 py-3 transition hover:bg-mist"><span><b className="block text-sm text-navy">{t.label}</b><span className="text-xs text-ink/55">{t.note}</span></span><ExternalLink size={14} className="shrink-0 text-ink/40" /></a></li>)}</ul>
          <p className="mt-3 border-t border-navy/10 pt-3 text-xs leading-5 text-ink/55">Önerilen sıra: Search Console'a siteyi ekleyin, doğrulama kodunu yapıştırın, <code>{base}/sitemap.xml</code> adresini gönderin.</p>
        </section>
      </div>

      <section id="denetim" className="scroll-mt-24 rounded-2xl border border-navy/10 bg-white shadow-sm">
        <div className="flex flex-wrap items-center justify-between gap-3 border-b border-navy/10 p-5">
          <h2 className="font-display text-lg font-bold text-navy">Sayfa bazlı SEO denetimi</h2>
          <div className="flex flex-wrap gap-2 text-sm">
            {[{ k: "", l: "Tümü", n: scored.length }, { k: "sorunlu", l: "Sorunlu", n: withIssues.length }, { k: "sorunsuz", l: "Sorunsuz", n: clean.length }].map((t) => (
              <Link key={t.k} href={t.k ? `/admin/seo?f=${t.k}#denetim` : "/admin/seo#denetim"} scroll={false} aria-current={f === t.k ? "true" : undefined} className={`rounded-full px-4 py-1.5 font-medium transition ${f === t.k ? "bg-navy text-white shadow" : "border border-navy/15 text-navy hover:bg-mist"}`}>{t.l} ({t.n})</Link>
            ))}
          </div>
        </div>
        <p className="border-b border-navy/5 bg-mist/60 px-5 py-2 text-xs text-ink/60">{f === "sorunlu" ? `Yalnızca sorunu olan ${shown.length} sayfa gösteriliyor` : f === "sorunsuz" ? `Sorunu olmayan ${shown.length} sayfa gösteriliyor` : `${shown.length} sayfanın tamamı gösteriliyor (en düşük puan üstte)`}</p>
        <div className="overflow-x-auto"><table className="w-full text-left text-sm">
          <thead className="bg-mist text-xs uppercase tracking-wide text-ink/60"><tr><th className="px-5 py-3">Sayfa</th><th className="px-5 py-3">Google'da görünecek başlık</th><th className="px-5 py-3">Sorunlar</th><th className="px-5 py-3 text-right">Puan</th><th /></tr></thead>
          <tbody>{shown.map((x) => (
            <tr key={x.type + x.path} className="border-t border-navy/5 align-top hover:bg-mist/60">
              <td className="px-5 py-3.5"><b className="block font-semibold text-navy">{x.title || "(başlıksız)"}</b><span className="text-xs text-ink/50">{x.type} · /tr{x.path === "/" ? "" : x.path}</span></td>
              <td className="max-w-sm px-5 py-3.5"><span className="line-clamp-1 text-[#1a0dab]">{x.effTitle}</span><span className="line-clamp-2 text-xs text-ink/60">{x.effDesc || <i>Açıklama yok</i>}</span></td>
              <td className="px-5 py-3.5"><div className="flex flex-wrap gap-1.5">{x.is.length ? x.is.map((i) => <Pill key={i.t} {...i} />) : <span className="inline-flex items-center gap-1 text-xs font-medium text-emerald-700"><CheckCircle2 size={14} />Sorun yok</span>}</div></td>
              <td className={`px-5 py-3.5 text-right font-display text-lg font-extrabold ${x.score >= 80 ? "text-emerald-600" : x.score >= 60 ? "text-amber" : "text-[#D93A17]"}`}>{x.score}</td>
              <td className="whitespace-nowrap px-5 py-3.5 text-right"><Link href={x.edit} className="rounded-full bg-teal px-3 py-1 text-xs font-semibold text-white hover:bg-navy">Düzenle</Link></td>
            </tr>))}
            {!shown.length && <tr><td colSpan={5} className="px-5 py-12 text-center text-ink/50">Bu filtreye uyan sayfa yok.</td></tr>}</tbody>
        </table></div>
      </section>
    </div>
  );
}
