import Link from "next/link";
import { ExternalLink, Pencil, Plus, Search } from "lucide-react";
import { notFound } from "next/navigation";
import { db } from "@/lib/db";
import { requirePermission } from "@/lib/auth";
import { can } from "@/lib/permissions";
import { RESOURCES } from "@/lib/resources";

export default async function List({ params, searchParams }: { params: Promise<{ resource: string }>; searchParams: Promise<{ q?: string; durum?: string }> }) {
  const { resource } = await params;
  const res = RESOURCES[resource];
  if (!res) notFound();
  const user = await requirePermission(res.perm);
  const sp = await searchParams;
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  let rows: any[] = await (db as any)[res.model].findMany({ orderBy: res.orderBy, ...(res.hasStatus && sp.durum ? { where: { status: sp.durum } } : {}), take: 500 });
  if (res.campusScoped && !can(user.role, "campus.all")) rows = rows.filter((r) => user.campusIds.includes(r.id));
  const q = sp.q?.toLocaleLowerCase("tr");
  if (q) rows = rows.filter((r) => res.columns.some((c) => c.get(r).toLocaleLowerCase("tr").includes(q)));
  const canCreate = !(res.campusScoped && !can(user.role, "campus.all"));
  const pill = (t: string) => {
    const tone = t === "Yayında" ? "bg-emerald-100 text-emerald-800" : t === "Taslak" ? "bg-amber/30 text-navy" : t === "Arşivlendi" ? "bg-navy/10 text-ink/60" : "bg-navy/5 text-navy";
    return <span className={`inline-flex items-center gap-1.5 rounded-full px-3 py-1 text-xs font-semibold ${tone}`}><span className="size-1.5 rounded-full bg-current" />{t}</span>;
  };
  const statusKeys = ["Yayında", "Taslak", "Arşivlendi"];
  return (
    <div>
      <div className="mb-6 flex flex-wrap items-end justify-between gap-3">
        <div><h1 className="font-display text-2xl font-extrabold text-navy">{res.label}</h1><p className="text-sm text-ink/55">{rows.length} kayıt{(sp.q || sp.durum) ? " (filtreli)" : ""}</p></div>
        {canCreate && <Link href={`/admin/r/${resource}/yeni`} className="btn-primary !min-h-10"><Plus size={16} />Yeni {res.singular}</Link>}
      </div>
      <form className="mb-4 flex flex-wrap gap-2">
        <label className="relative"><Search size={15} className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-ink/40" /><input name="q" defaultValue={sp.q} placeholder="Ara…" className="field !w-72 !py-2 !pl-9" /></label>
        {res.hasStatus && <select name="durum" defaultValue={sp.durum ?? ""} className="field !w-44 !py-2"><option value="">Tüm durumlar</option><option value="DRAFT">Taslak</option><option value="PUBLISHED">Yayında</option><option value="ARCHIVED">Arşiv</option></select>}
        <button className="btn-outline !min-h-10">Filtrele</button>
        {(sp.q || sp.durum) && <Link href={`/admin/r/${resource}`} className="inline-flex items-center px-2 text-sm text-ink/60 underline">Temizle</Link>}
      </form>
      <div className="overflow-x-auto rounded-2xl border border-navy/10 bg-white shadow-sm"><table className="w-full text-left text-sm">
        <thead className="border-b border-navy/10 bg-mist text-xs uppercase tracking-wide text-ink/60"><tr>{res.columns.map((c) => <th key={c.label} className="px-5 py-3.5">{c.label}</th>)}<th /></tr></thead>
        <tbody>{rows.map((r) => {
          const url = res.publicUrl?.(r);
          return (
            <tr key={r.id} className="group border-b border-navy/5 transition last:border-0 hover:bg-mist/60">
              {res.columns.map((c, i) => { const v = c.get(r); return <td key={c.label} className="px-5 py-3.5">{i === 0 ? <Link className="font-semibold text-navy hover:text-teal" href={`/admin/r/${resource}/${r.id}`}>{v || "(başlıksız)"}</Link> : statusKeys.includes(v) ? pill(v) : <span className="text-ink/75">{v}</span>}</td>; })}
              <td className="whitespace-nowrap px-5 py-3.5 text-right">
                <span className="inline-flex items-center gap-2 opacity-70 transition group-hover:opacity-100">
                  {url && <a href={url} target="_blank" rel="noopener" className="inline-flex items-center gap-1 rounded-full border border-navy/15 px-3 py-1 text-xs text-navy hover:bg-navy hover:text-white"><ExternalLink size={12} />Sitede aç</a>}
                  <Link href={`/admin/r/${resource}/${r.id}`} className="inline-flex items-center gap-1 rounded-full bg-teal px-3 py-1 text-xs font-semibold text-white hover:bg-navy"><Pencil size={12} />Düzenle</Link>
                </span>
              </td>
            </tr>
          );
        })}
          {!rows.length && <tr><td colSpan={res.columns.length + 1} className="px-5 py-14 text-center text-ink/50">{sp.q || sp.durum ? "Aramanıza uyan kayıt yok." : `Henüz ${res.singular.toLocaleLowerCase("tr")} yok.`}</td></tr>}</tbody></table></div>
    </div>
  );
}
