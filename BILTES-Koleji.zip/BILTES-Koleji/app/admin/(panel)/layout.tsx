import { requireUser } from "@/lib/auth";
import { can, ROLE_LABEL, type Permission } from "@/lib/permissions";
import { logout } from "@/app/actions/auth";
import { db } from "@/lib/db";
import { getSettings } from "@/lib/settings";
import { AdminShell } from "@/components/admin/AdminShell";

// Hangi menü bağlantısı hangi yetkiyi gerektirir (menünün görünümü AdminShell'dedir).
const PERMS: Record<string, Permission> = {
  "/admin": "campus.own", "/admin/anasayfa": "content", "/admin/r/hero": "content", "/admin/r/pages": "content", "/admin/r/campuses": "campus.own", "/admin/r/programs": "content",
  "/admin/r/news": "content", "/admin/r/categories": "content", "/admin/r/events": "content", "/admin/r/achievements": "content", "/admin/r/clubs": "content", "/admin/r/testimonials": "content",
  "/admin/medya": "media", "/admin/menuler": "menus", "/admin/r/redirects": "redirects", "/admin/leads": "leads.view", "/admin/seo": "content", "/admin/ayarlar": "settings", "/admin/kullanicilar": "users", "/admin/denetim": "audit",
};

export default async function Panel({ children }: { children: React.ReactNode }) {
  const u = await requireUser();
  const allowed = Object.entries(PERMS).filter(([, p]) => can(u.role, p)).map(([href]) => href);
  const [newLeads, s] = await Promise.all([can(u.role, "leads.view") ? db.lead.count({ where: { status: "NEW" } }) : 0, getSettings()]);
  return (
    <AdminShell allowed={allowed} badges={{ "/admin/leads": newLeads }} user={{ name: u.name, role: ROLE_LABEL[u.role] }} logoUrl={s.logoUrl} logout={logout}>
      {children}
    </AdminShell>
  );
}
