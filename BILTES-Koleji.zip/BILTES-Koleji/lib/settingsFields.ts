import type { Field } from "./forms";
export const SETTINGS_FIELDS: Field[] = [
  { name: "siteTitle", label: "Site başlığı", type: "text" },
  { name: "siteDescription", label: "Varsayılan site açıklaması (SEO)", type: "textarea" },
  { name: "logoUrl", label: "Logo", type: "image" }, { name: "logoMobileUrl", label: "Mobil logo", type: "image" }, { name: "faviconUrl", label: "Favicon", type: "image" },
  { name: "colors", label: "Kurumsal renkler (HEX)", type: "group", fields: [{ name: "navy", label: "Lacivert", type: "text" }, { name: "turquoise", label: "Ana vurgu (düğmeler, bağlantılar)", type: "text" }, { name: "accent", label: "Vurgu", type: "text" }] },
  { name: "contact", label: "İletişim bilgileri", type: "group", fields: [{ name: "phone", label: "Telefon", type: "text" }, { name: "email", label: "E-posta", type: "email" }, { name: "address", label: "Adres", type: "textarea" }, { name: "whatsapp", label: "WhatsApp numarası", type: "text", hint: "Ülke koduyla, örn. 90 5xx xxx xx xx. Doldurulunca sitede WhatsApp düğmesi görünür; boşsa düğme gizlenir." }] },
  { name: "company", label: "Resmî kurum bilgileri (alt bilgide ve yasal sayfalarda gösterilir; boş bırakılanlar gizlenir)", type: "group", fields: [
    { name: "title", label: "Ticari unvan", type: "text" }, { name: "mersis", label: "MERSİS no", type: "text" }, { name: "tradeRegistry", label: "Ticaret sicil no", type: "text" },
    { name: "taxId", label: "Vergi dairesi / vergi no", type: "text" }, { name: "kep", label: "KEP adresi", type: "text" }, { name: "institutionCode", label: "MEB kurum kodu", type: "text" }] },
  { name: "social", label: "Sosyal medya", type: "group", fields: [{ name: "facebook", label: "Facebook", type: "url" }, { name: "instagram", label: "Instagram", type: "url" }, { name: "twitter", label: "X / Twitter", type: "url" }, { name: "youtube", label: "YouTube", type: "url" }] },
  { name: "footerText", label: "Alt bilgi metni", type: "textarea", localized: true },
  { name: "integrations", label: "Entegrasyon bağlantıları", type: "group", fields: [
    { name: "veli", label: "Veli Portalı", type: "url" }, { name: "digital", label: "BİLTES Digital", type: "url" }, { name: "k12", label: "K12", type: "url" },
    { name: "franchise", label: "Franchise başvuru", type: "url" }, { name: "hr", label: "İnsan Kaynakları", type: "url" }, { name: "complaint", label: "Şikayet ve memnuniyet", type: "url" }] },
  { name: "groupImages", label: "Bölüm başlık görselleri (görseli olmayan sayfalarda kullanılır)", type: "group", fields: [{ name: "kurumsal", label: "Kurumsal", type: "image" }, { name: "egitim", label: "Eğitim", type: "image" }, { name: "hayat", label: "BİLTES'te Yaşam", type: "image" }, { name: "uluslararasi", label: "Uluslararası", type: "image" }, { name: "kayit", label: "Kayıt", type: "image" }] },
  { name: "seo", label: "Arama motoru (SEO) ayarları", type: "group", fields: [
    { name: "homeTitle", label: "Ana sayfa Google başlığı", type: "text", max: 60, hint: "Google'da ana sayfanın başlığı. Boşsa yalnızca site adı kullanılır. Anahtar kelime ekleyin (örn. anaokulu, ilkokul, ortaokul, İstanbul)." },
    { name: "googleVerification", label: "Google Search Console doğrulama kodu", type: "text", hint: "Search Console → Ayarlar → Sahiplik doğrulama → HTML etiketi içindeki content=\"…\" değeri. Yalnızca kodu yapıştırın." },
    { name: "bingVerification", label: "Bing Webmaster doğrulama kodu", type: "text", hint: "İsteğe bağlı. msvalidate.01 etiketinin content değeri." },
    { name: "defaultOgImage", label: "Varsayılan paylaşım görseli (WhatsApp, sosyal medya, Google)", type: "image", hint: "Kendi görseli olmayan sayfalarda kullanılır. Önerilen boyut 1200×630." },
    { name: "noindex", label: "Siteyi arama motorlarından gizle (noindex)", type: "bool", hint: "Site yayına çıkmadan önce açık tutabilirsiniz. Yayına alırken KAPATMAYI unutmayın: açıkken Google siteyi listelemez." },
  ] },
  { name: "gaId", label: "Google Analytics ölçüm kimliği (yalnızca çerez onayından sonra yüklenir)", type: "text" },
];
