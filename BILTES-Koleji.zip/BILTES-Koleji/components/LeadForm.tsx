"use client";
import { startTransition, useActionState, useState } from "react";
import { motion } from "motion/react";
import { Baby, BookOpen, Building2, CalendarDays, CheckCircle2, GraduationCap, Mail, MessageSquare, Phone, Send, ShieldCheck, User } from "lucide-react";
import { submitLead, type LeadState } from "@/app/actions/lead";
import { UI, type Locale } from "@/lib/i18n";
import Link from "next/link";

const LEVELS = [
  { v: "anaokulu", tr: "Anaokulu", en: "Preschool", icon: Baby },
  { v: "ilkokul", tr: "İlkokul", en: "Primary", icon: BookOpen },
  { v: "ortaokul", tr: "Ortaokul", en: "Middle school", icon: GraduationCap },
];

export function LeadForm({ locale, campuses, source = "bilgi-talebi", defaultCampusId = "" }: { locale: Locale; campuses: { id: string; name: string }[]; source?: "bilgi-talebi" | "ziyaret" | "kampus-formu"; defaultCampusId?: string }) {
  const [state, action, pending] = useActionState<LeadState, FormData>(submitLead, { ok: false });
  const [level, setLevel] = useState("");
  const t = UI[locale];
  const tr = locale === "tr";
  if (state.ok) {
    return (
      <motion.div role="status" initial={{ opacity: 0, scale: 0.96 }} animate={{ opacity: 1, scale: 1 }} className="rounded-3xl border border-teal/30 bg-gradient-to-br from-teal/10 to-white p-10 text-center shadow-sm">
        <span className="mx-auto grid size-16 place-items-center rounded-full bg-teal text-white"><CheckCircle2 size={34} /></span>
        <h3 className="mt-5 font-display text-2xl font-extrabold text-navy">{tr ? "Teşekkürler!" : "Thank you!"}</h3>
        <p className="mx-auto mt-2 max-w-md text-lg text-ink/80">{t.thanks}</p>
      </motion.div>
    );
  }
  const e = state.errors ?? {};
  const Err = ({ k }: { k: string }) => (e[k] ? <p role="alert" className="mt-1.5 text-sm text-red-700">{e[k]}</p> : null);
  const lbl = "mb-1.5 block text-sm font-semibold text-navy";
  const ico = "pointer-events-none absolute left-3.5 top-1/2 -translate-y-1/2 text-teal";
  const inp = "field !rounded-xl !border-navy/15 !bg-mist/50 !pl-11 transition focus:!bg-white focus:!ring-4 focus:!ring-teal/15";
  return (
    <form id="bilgi-formu" onSubmit={(ev) => { ev.preventDefault(); const fd = new FormData(ev.currentTarget); startTransition(() => action(fd)); }} className="grid scroll-mt-28 gap-5 rounded-3xl border border-navy/10 bg-white p-6 shadow-xl shadow-navy/5 md:grid-cols-2 md:p-9" noValidate>
      <input type="hidden" name="source" value={source} /><input type="hidden" name="locale" value={locale} />
      <input type="hidden" name="level" value={level} />
      <div className="hidden" aria-hidden><label>Web sitesi<input name="website" tabIndex={-1} autoComplete="off" /></label></div>

      <div className="md:col-span-2"><label className={lbl} htmlFor="parentName">{t.name} *</label>
        <div className="relative"><User size={18} className={ico} /><input id="parentName" name="parentName" required autoComplete="name" className={inp} /></div><Err k="parentName" /></div>
      <div><label className={lbl} htmlFor="phone">{t.phone} *</label>
        <div className="relative"><Phone size={18} className={ico} /><input id="phone" name="phone" type="tel" required autoComplete="tel" placeholder="05xx xxx xx xx" className={inp} /></div><Err k="phone" /></div>
      <div><label className={lbl} htmlFor="email">{t.email} *</label>
        <div className="relative"><Mail size={18} className={ico} /><input id="email" name="email" type="email" required autoComplete="email" className={inp} /></div><Err k="email" /></div>

      <fieldset className="md:col-span-2"><legend className={lbl}>{t.level}</legend>
        <div className="grid grid-cols-3 gap-3">
          {LEVELS.map((l) => {
            const on = level === l.v;
            return (
              <button type="button" key={l.v} aria-pressed={on} onClick={() => setLevel(on ? "" : l.v)}
                className={`flex flex-col items-center gap-2 rounded-xl border-2 px-2 py-4 text-sm font-semibold transition ${on ? "border-teal bg-teal/10 text-navy shadow-sm" : "border-navy/10 bg-mist/40 text-ink/70 hover:border-teal/50 hover:bg-white"}`}>
                <l.icon size={24} className={on ? "text-teal" : "text-ink/40"} />{tr ? l.tr : l.en}
              </button>
            );
          })}
        </div>
      </fieldset>

      <div><label className={lbl} htmlFor="campusId">{t.campus}</label>
        <div className="relative"><Building2 size={18} className={ico} />
          <select id="campusId" name="campusId" defaultValue={defaultCampusId} className={inp}><option value="">{t.select}</option>{campuses.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}</select></div></div>
      <div><label className={lbl} htmlFor="studentAge">{t.age}</label>
        <div className="relative"><CalendarDays size={18} className={ico} /><input id="studentAge" name="studentAge" className={inp} maxLength={40} /></div></div>
      <div className="md:col-span-2"><label className={lbl} htmlFor="message">{t.message}</label>
        <div className="relative"><MessageSquare size={18} className="pointer-events-none absolute left-3.5 top-4 text-teal" /><textarea id="message" name="message" rows={4} className={`${inp} resize-y`} maxLength={2000} /></div></div>

      <div className="space-y-3 rounded-xl bg-mist/60 p-4 md:col-span-2">
        <label className="flex gap-3 text-sm leading-6"><input type="checkbox" name="privacy" required className="mt-1.5 h-4 w-4 accent-teal" /><span>{t.privacy} (<Link href={`/${locale}/yasal/kvkk-aydinlatma-metni`} className="text-teal underline" target="_blank">KVKK</Link>) *</span></label><Err k="privacy" />
        <label className="flex gap-3 text-sm leading-6"><input type="checkbox" name="marketing" className="mt-1.5 h-4 w-4 accent-teal" /><span>{t.marketing}</span></label>
      </div>
      {state.message && <p role="alert" className="text-red-700 md:col-span-2">{state.message}</p>}
      <div className="flex flex-wrap items-center gap-4 md:col-span-2">
        <button disabled={pending} className="btn-primary group w-full gap-2 !rounded-xl md:w-auto">{pending ? "…" : <>{t.sendRequest}<Send size={17} className="transition group-hover:translate-x-1" /></>}</button>
        <span className="inline-flex items-center gap-2 text-xs text-ink/55"><ShieldCheck size={15} className="text-teal" />{tr ? "Bilgileriniz yalnızca başvurunuzu yanıtlamak için kullanılır." : "Your details are used only to respond to your enquiry."}</span>
      </div>
    </form>
  );
}
