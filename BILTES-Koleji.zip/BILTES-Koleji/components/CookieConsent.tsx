"use client";
import { useEffect, useState } from "react";
import Link from "next/link";

const KEY = "biltes_consent";
const EVENT = "biltes:cookie-prefs";

function loadGa(gaId: string) {
  if (!gaId || document.getElementById("ga")) return;
  const s = document.createElement("script"); s.id = "ga"; s.async = true; s.src = `https://www.googletagmanager.com/gtag/js?id=${gaId}`; document.head.appendChild(s);
  const w = window as unknown as { dataLayer: unknown[] }; w.dataLayer = w.dataLayer || [];
  w.dataLayer.push(["js", new Date()], ["config", gaId, { anonymize_ip: true }]);
}
function clearGa() {
  for (const c of document.cookie.split(";")) {
    const n = c.split("=")[0].trim();
    if (n.startsWith("_ga") || n.startsWith("_gid")) {
      document.cookie = `${n}=; expires=Thu, 01 Jan 1970 00:00:00 GMT; path=/`;
      document.cookie = `${n}=; expires=Thu, 01 Jan 1970 00:00:00 GMT; path=/; domain=.${location.hostname.replace(/^www\./, "")}`;
    }
  }
}

/** Çerez bildirimi: Reddet ve Kabul et eşit görünürlükte; ayrıntılı tercih paneli; alt bilgideki bağlantıdan yeniden açılır. */
export function CookieConsent({ locale, gaId }: { locale: "tr" | "en"; gaId: string }) {
  const [state, setState] = useState<string | null>("pending"); // "pending" = yükleniyor, null = henüz karar yok (bildirim görünür)
  const [panel, setPanel] = useState(false);
  const [analytics, setAnalytics] = useState(false);
  useEffect(() => {
    let v: string | null = null;
    try { v = localStorage.getItem(KEY); } catch {}
    setState(v); setAnalytics(v === "all");
    if (v === "all") loadGa(gaId);
    const open = () => setPanel(true);
    window.addEventListener(EVENT, open);
    return () => window.removeEventListener(EVENT, open);
  }, [gaId]);
  const tr = locale === "tr";
  const t = tr
    ? { title: "Çerez tercihleri", text: "Sitemizi çalıştırmak için zorunlu çerezler kullanıyoruz. Analitik çerezler yalnızca onayınızla etkinleşir.", reject: "Reddet", prefs: "Tercihleri yönet", accept: "Kabul et", more: "Ayrıntılar", necessary: "Zorunlu çerezler", necessaryText: "Sitenin güvenli ve doğru çalışması için gereklidir; kapatılamaz.", analytics: "Analitik çerezler", analyticsText: "Ziyaretlerin nasıl kullanıldığını anonim olarak ölçmemize yardımcı olur (Google Analytics).", always: "Her zaman açık", save: "Tercihleri kaydet", close: "Kapat" }
    : { title: "Cookie preferences", text: "We use strictly necessary cookies. Analytics cookies are only enabled with your consent.", reject: "Reject", prefs: "Manage preferences", accept: "Accept", more: "Details", necessary: "Strictly necessary cookies", necessaryText: "Required for the site to work securely and correctly; cannot be switched off.", analytics: "Analytics cookies", analyticsText: "Help us measure anonymously how the site is used (Google Analytics).", always: "Always on", save: "Save preferences", close: "Close" };
  const decide = (v: "all" | "necessary") => {
    const was = (() => { try { return localStorage.getItem(KEY); } catch { return null; } })();
    try { localStorage.setItem(KEY, v); } catch {}
    setState(v); setPanel(false); setAnalytics(v === "all");
    if (v === "all") loadGa(gaId);
    else if (was === "all") { clearGa(); location.reload(); }
  };
  const btn = "rounded-full border border-white/50 px-5 py-2.5 text-sm font-semibold transition hover:bg-white hover:text-navy";
  return (
    <>
      {state === null && !panel && (
        <div role="dialog" aria-label={t.title} className="fixed inset-x-3 bottom-3 z-[70] mx-auto max-w-4xl rounded-xl bg-navy p-5 text-sm text-white shadow-2xl md:flex md:items-center md:gap-6">
          <p className="flex-1 leading-6">{t.text} <Link href={`/${locale}/yasal/cerez-tercihleri`} className="underline">{t.more}</Link></p>
          <div className="mt-4 flex flex-wrap gap-2 md:mt-0 md:shrink-0">
            <button onClick={() => decide("necessary")} className={btn}>{t.reject}</button>
            <button onClick={() => setPanel(true)} className="rounded-full px-3 py-2.5 text-sm font-semibold underline underline-offset-4 hover:text-amber">{t.prefs}</button>
            <button onClick={() => decide("all")} className={btn}>{t.accept}</button>
          </div>
        </div>
      )}
      {panel && (
        <div className="fixed inset-0 z-[80] grid place-items-center bg-black/60 p-4" role="dialog" aria-modal="true" aria-label={t.title} onClick={() => setPanel(false)}>
          <div className="w-full max-w-lg rounded-2xl bg-white p-6 text-ink shadow-2xl md:p-8" onClick={(e) => e.stopPropagation()}>
            <h2 className="font-display text-2xl font-extrabold text-navy">{t.title}</h2>
            <div className="mt-6 space-y-5">
              <div className="flex items-start justify-between gap-4 border-b border-navy/10 pb-5">
                <div><h3 className="font-semibold text-navy">{t.necessary}</h3><p className="mt-1 text-sm text-ink/70">{t.necessaryText}</p></div>
                <span className="shrink-0 rounded-full bg-navy/10 px-3 py-1 text-xs font-semibold text-navy">{t.always}</span>
              </div>
              <div className="flex items-start justify-between gap-4">
                <div><h3 className="font-semibold text-navy">{t.analytics}</h3><p className="mt-1 text-sm text-ink/70">{t.analyticsText}</p></div>
                <button role="switch" aria-checked={analytics} aria-label={t.analytics} onClick={() => setAnalytics((a) => !a)} className={`relative h-7 w-12 shrink-0 rounded-full transition ${analytics ? "bg-teal" : "bg-navy/25"}`}>
                  <span className={`absolute top-0.5 size-6 rounded-full bg-white shadow transition-all ${analytics ? "left-[22px]" : "left-0.5"}`} />
                </button>
              </div>
            </div>
            <div className="mt-8 flex flex-wrap justify-end gap-2">
              <button onClick={() => setPanel(false)} className="rounded-full px-4 py-2.5 text-sm font-semibold text-navy hover:underline">{t.close}</button>
              <button onClick={() => decide(analytics ? "all" : "necessary")} className="btn-dark !py-2.5">{t.save}</button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}

/** Alt bilgide: çerez tercihlerini yeniden açar. */
export function CookieSettingsButton({ label }: { label: string }) {
  return <button type="button" onClick={() => window.dispatchEvent(new Event(EVENT))} className="hover:text-white">{label}</button>;
}
