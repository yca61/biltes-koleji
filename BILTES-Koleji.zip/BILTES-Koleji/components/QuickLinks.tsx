"use client";
import Link from "next/link";
import { useEffect, useRef, useState } from "react";
import { motion, useInView, useReducedMotion } from "motion/react";
import { ArrowUpRight, Building2, GraduationCap, Palette, FileSignature } from "lucide-react";

const ITEMS = [
  { key: "kampusler", href: "kampusler", icon: Building2, tr: ["Kampüslerimiz", "Sadabad, Sadabad Anaokulu ve Göktürk kampüslerimizi keşfedin."], en: ["Our Campuses", "Discover our Sadabad, Sadabad Preschool and Göktürk campuses."] },
  { key: "egitim", href: "egitim", icon: GraduationCap, tr: ["Eğitim Programlarımız", "Anaokulu, ilkokul ve ortaokul programlarımızı ve eğitim yaklaşımımızı inceleyin."], en: ["Education", "Explore our preschool, primary and middle school programmes and our approach."] },
  { key: "hayat", href: "hayat", icon: Palette, tr: ["BİLTES'te Yaşam", "Atölyeler, kulüpler ve okul hayatından kareler."], en: ["Life at BİLTES", "Workshops, clubs and moments from school life."] },
  { key: "kayit", href: "kayit", icon: FileSignature, tr: ["Ön Kayıt", "Başvuru ve kayıt sürecini öğrenin, görüşme için bizimle iletişime geçin."], en: ["Admissions", "Learn about applying and enrolment, and get in touch to arrange a meeting."] },
] as const;

/** Hero altında genişleyen görsel paneller: üzerine gelen panel açılır, diğerleri daralır (mobilde alt alta). */
export function QuickLinks({ locale, images }: { locale: "tr" | "en"; images: Record<string, string | undefined> }) {
  const reduce = useReducedMotion();
  const [active, setActive] = useState(0);
  const discover = locale === "tr" ? "Keşfet" : "Explore";
  const [paused, setPaused] = useState(false);
  const box = useRef<HTMLElement>(null);
  const inView = useInView(box, { margin: "-80px" });
  const auto = !reduce && !paused && inView;
  const STEP = 4500;
  // Fare/odak yokken paneller sırayla kendiliğinden açılır.
  useEffect(() => {
    if (!auto) return;
    const t = setTimeout(() => setActive((a) => (a + 1) % ITEMS.length), STEP);
    return () => clearTimeout(t);
  }, [auto, active]);
  return (
    <nav ref={box} aria-label={locale === "tr" ? "Hızlı erişim" : "Quick links"} className="relative z-10 bg-white px-4 py-10 md:px-6 md:py-16">
      <ul className="mx-auto flex max-w-7xl flex-col gap-3 lg:h-[30rem] lg:flex-row lg:gap-4" onMouseEnter={() => setPaused(true)} onMouseLeave={() => setPaused(false)} onFocusCapture={() => setPaused(true)} onBlurCapture={() => setPaused(false)}>
        {ITEMS.map((it, i) => {
          const [title, sub] = it[locale];
          const Icon = it.icon;
          const open = active === i;
          const img = images[it.key];
          return (
            <motion.li
              key={it.key}
              className="min-h-[15rem] overflow-hidden rounded-3xl transition-[flex-grow] duration-700 ease-[cubic-bezier(.22,1,.36,1)] lg:min-h-0 lg:basis-0"
              style={{ flexGrow: open ? 2.2 : 1 }}
              initial={reduce ? false : { opacity: 0, y: 40 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-30px" }}
              transition={{ duration: 0.8, delay: i * 0.1, ease: [0.22, 1, 0.36, 1] }}
              onMouseEnter={() => setActive(i)}
              onFocusCapture={() => setActive(i)}
            >
              <Link href={`/${locale}/${it.href}`} className="group relative block h-full min-h-[15rem] w-full bg-navy lg:min-h-0">
                {img && <img src={img} alt="" loading="lazy" className={`absolute inset-0 h-full w-full object-cover transition-transform duration-[1200ms] ease-out ${open ? "scale-105" : "scale-100"}`} />}
                <span aria-hidden className={`absolute inset-0 bg-gradient-to-t from-navy via-navy/40 to-navy/10 transition-opacity duration-700 ${open ? "opacity-90" : "opacity-100"}`} />
                <span aria-hidden className={`absolute inset-0 bg-navy/30 transition-opacity duration-700 ${open ? "opacity-0" : "opacity-100"}`} />
                <span className="absolute left-5 top-5 font-display text-sm font-bold tracking-widest text-white/80">0{i + 1}</span>
                <motion.span
                  className={`absolute right-5 top-5 grid size-12 place-items-center rounded-full backdrop-blur transition-colors duration-500 ${open ? "bg-amber text-navy" : "bg-white/15 text-white"}`}
                  animate={reduce ? undefined : open ? { rotate: [0, -12, 12, 0], scale: [1, 1.25, 1] } : { rotate: 0, scale: 1 }}
                  transition={{ duration: 0.8, ease: "easeOut" }}
                >
                  {open && !reduce && <span aria-hidden className="absolute inset-0 animate-ping rounded-full bg-amber/50" style={{ animationIterationCount: 2 }} />}
                  <Icon size={22} strokeWidth={1.75} className="relative" />
                </motion.span>
                {open && !reduce && <motion.span key={`shine-${active}`} aria-hidden className="pointer-events-none absolute inset-y-0 -left-1/3 w-1/3 -skew-x-12 bg-gradient-to-r from-transparent via-white/25 to-transparent" initial={{ x: "-100%" }} animate={{ x: "420%" }} transition={{ duration: 1.1, ease: "easeInOut", delay: 0.15 }} />}
                <span className="absolute inset-x-0 bottom-0 flex items-end justify-between gap-4 p-5 text-white md:p-7">
                  <span className="min-w-0">
                    <span className="block font-display text-xl font-extrabold leading-tight md:text-2xl">{title}</span>
                    <span className={`grid transition-all duration-700 ease-out ${open ? "mt-3 grid-rows-[1fr] opacity-100" : "grid-rows-[1fr] opacity-100 lg:mt-0 lg:grid-rows-[0fr] lg:opacity-0"}`}>
                      <span className="overflow-hidden">
                        <span className={`block max-w-sm text-sm leading-6 text-white/85 transition-all duration-700 ${open ? "translate-y-0 opacity-100 delay-200" : "max-lg:translate-y-0 max-lg:opacity-100 translate-y-4 opacity-0"}`}>{sub}</span>
                        <span className={`mt-4 inline-flex items-center gap-2 border-b-2 border-amber pb-1 text-sm font-semibold transition-all duration-700 ${open ? "translate-y-0 opacity-100 delay-300" : "max-lg:translate-y-0 max-lg:opacity-100 translate-y-4 opacity-0"}`}>{discover}<ArrowUpRight size={16} className="transition-transform group-hover:-translate-y-0.5 group-hover:translate-x-0.5" /></span>
                      </span>
                    </span>
                  </span>
                </span>
                <span aria-hidden className="absolute inset-x-0 bottom-0 h-1 bg-white/15" />
                {open && (reduce || paused || !inView
                  ? <span aria-hidden className="absolute inset-x-0 bottom-0 h-1 bg-amber" />
                  : <motion.span key={`bar-${active}`} aria-hidden className="absolute inset-x-0 bottom-0 h-1 origin-left bg-amber" initial={{ scaleX: 0 }} animate={{ scaleX: 1 }} transition={{ duration: STEP / 1000, ease: "linear" }} />)}
              </Link>
            </motion.li>
          );
        })}
      </ul>
    </nav>
  );
}
