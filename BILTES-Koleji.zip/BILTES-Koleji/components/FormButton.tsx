"use client";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { ClipboardPen } from "lucide-react";
import type { Locale } from "@/lib/i18n";

/** Sağ altta sabit "Bilgi talebi formu" düğmesi; iletişim sayfasında gizlenir. */
export function FormButton({ locale }: { locale: Locale }) {
  const path = usePathname();
  if (path.endsWith("/iletisim")) return null;
  const label = locale === "tr" ? "Bilgi talep formu" : "Enquiry form";
  return (
    <Link href={`/${locale}/iletisim#bilgi-formu`} aria-label={label}
      className="group fixed bottom-5 right-5 z-40 flex items-center gap-3 print:hidden">
      <span className="pointer-events-none translate-x-2 rounded-full bg-navy px-4 py-2 text-sm font-semibold text-white opacity-0 shadow-lg transition group-hover:translate-x-0 group-hover:opacity-100 group-focus-visible:translate-x-0 group-focus-visible:opacity-100 max-sm:hidden">{label}</span>
      <span className="relative grid size-14 place-items-center rounded-full bg-teal text-white shadow-lg shadow-black/25 transition group-hover:scale-110 group-hover:bg-navy">
        <span aria-hidden className="wa-ping absolute inset-0 rounded-full bg-teal" />
        <ClipboardPen size={26} className="relative" />
      </span>
    </Link>
  );
}
