"use client";
import { useEffect, useState } from "react";
import { X } from "lucide-react";
import type { Locale } from "@/lib/i18n";

const TEXT = {
  tr: { label: "WhatsApp ile yazın", hello: "Merhaba, BİLTES Koleji hakkında bilgi almak istiyorum.", bubble: "Sorularınız mı var? Bize WhatsApp'tan yazın." },
  en: { label: "Chat on WhatsApp", hello: "Hello, I would like information about BİLTES Koleji.", bubble: "Any questions? Message us on WhatsApp." },
};

/** Numara yalnızca rakam olarak, ülke koduyla (05xx… → 905xx…). */
export function waNumber(raw: string) {
  const d = raw.replace(/\D/g, "");
  if (d.startsWith("00")) return d.slice(2);
  if (d.startsWith("0")) return "90" + d.slice(1);
  if (d.length === 10) return "90" + d;
  return d;
}

/** Sağ altta sabit WhatsApp düğmesi. Numara Site Ayarları'ndan girilmediyse hiç görünmez. */
export function WhatsAppButton({ locale, number }: { locale: Locale; number: string }) {
  const [bubble, setBubble] = useState(false);
  useEffect(() => {
    let seen = false;
    try { seen = sessionStorage.getItem("biltes:wa") === "1"; } catch {}
    if (seen) return;
    const t = setTimeout(() => setBubble(true), 4000);
    return () => clearTimeout(t);
  }, []);
  const n = waNumber(number);
  if (n.length < 10) return null;
  const t = TEXT[locale];
  const close = () => { setBubble(false); try { sessionStorage.setItem("biltes:wa", "1"); } catch {} };
  return (
    <div className="fixed bottom-5 left-5 z-40 flex items-end gap-3 print:hidden">
      <a href={`https://wa.me/${n}?text=${encodeURIComponent(t.hello)}`} target="_blank" rel="noopener noreferrer" aria-label={t.label} onClick={close}
        className="group relative grid size-14 shrink-0 place-items-center rounded-full bg-[#25D366] text-white shadow-lg shadow-black/25 transition hover:scale-110 hover:shadow-xl focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#25D366]">
        <span aria-hidden className="wa-ping absolute inset-0 rounded-full bg-[#25D366]" />
        <svg viewBox="0 0 32 32" aria-hidden className="relative size-8 fill-current"><path d="M16.003 3C8.83 3 3 8.83 3 16c0 2.29.6 4.53 1.74 6.5L3 29l6.66-1.7A12.95 12.95 0 0 0 16 29c7.17 0 13-5.83 13-13S23.17 3 16.003 3Zm0 23.8c-1.95 0-3.86-.53-5.53-1.52l-.4-.24-3.95 1.01 1.06-3.85-.26-.4A10.76 10.76 0 0 1 5.2 16C5.2 10.04 10.04 5.2 16 5.2S26.8 10.04 26.8 16 21.96 26.8 16 26.8Zm5.92-8.07c-.32-.16-1.92-.95-2.22-1.06-.3-.11-.51-.16-.73.16-.22.32-.84 1.06-1.03 1.28-.19.22-.38.24-.7.08-.32-.16-1.37-.5-2.6-1.6-.96-.86-1.6-1.91-1.8-2.23-.19-.32-.02-.5.14-.66.15-.14.32-.38.49-.57.16-.19.22-.32.32-.54.11-.22.05-.4-.03-.57-.08-.16-.73-1.76-1-2.4-.26-.63-.53-.54-.73-.55h-.62c-.22 0-.57.08-.87.4-.3.32-1.14 1.11-1.14 2.72s1.17 3.16 1.33 3.38c.16.22 2.3 3.51 5.57 4.92.78.34 1.38.54 1.85.69.78.25 1.49.21 2.05.13.63-.09 1.92-.78 2.19-1.54.27-.76.27-1.4.19-1.54-.08-.14-.3-.22-.62-.38Z" /></svg>
      </a>
      {bubble && (
        <div role="status" className="wa-bubble relative max-w-[15rem] rounded-2xl rounded-bl-sm bg-white p-4 pr-9 text-sm leading-5 text-navy shadow-xl ring-1 ring-navy/10">
          {t.bubble}
          <button onClick={close} aria-label={locale === "tr" ? "Kapat" : "Close"} className="absolute right-2 top-2 grid size-6 place-items-center rounded-full text-ink/50 hover:bg-mist hover:text-navy"><X size={14} /></button>
        </div>
      )}
    </div>
  );
}
