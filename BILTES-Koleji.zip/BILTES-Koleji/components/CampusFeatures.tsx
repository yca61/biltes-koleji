import { Baby, Compass, Cpu, Dumbbell, FlaskConical, Globe, HeartHandshake, HeartPulse, Library, Monitor, Music, Palette, PersonStanding, Salad, School, Snowflake, Utensils, BadgeCheck, type LucideIcon } from "lucide-react";
import { Reveal } from "./Reveal";

const ICONS: [RegExp, LucideIcon][] = [
  [/buz|pateni|ice/i, Snowflake], [/yemekhane|dining/i, Utensils], [/kütüphane|library/i, Library], [/müzik|music/i, Music], [/fen lab|science/i, FlaskConical],
  [/adab|etiquette/i, HeartHandshake], [/spor|gym/i, Dumbbell], [/bilgisayar|computer/i, Monitor], [/resim|art stud/i, Palette], [/teknoloji|technology/i, Cpu],
  [/dans|dance/i, PersonStanding], [/rehberlik|counsel/i, Compass], [/revir|hemşire|nurse|infirmary/i, HeartPulse], [/beslenme|menü|menu|nutrition/i, Salad],
  [/yaş|age/i, Baby], [/uluslararası|international/i, Globe], [/sınıf|classroom/i, School],
];
const iconFor = (t: string) => ICONS.find(([re]) => re.test(t))?.[1] ?? BadgeCheck;

/** Kampüs özellikleri: ikonlu kartlar. */
export function CampusFeatures({ title, items }: { title: string; items: string[] }) {
  return (
    <section>
      <h2 className="mb-6 text-3xl font-semibold">{title}</h2>
      <ul className="grid gap-3 sm:grid-cols-2 xl:grid-cols-3">
        {items.map((t, i) => {
          const Icon = iconFor(t);
          return (
            <Reveal key={i} delay={(i % 3) * 0.06}>
              <li className="group flex h-full items-center gap-4 rounded-2xl border border-navy/10 bg-white p-4 transition duration-300 hover:-translate-y-1 hover:border-teal/40 hover:shadow-[0_16px_30px_-18px_rgba(27,58,120,0.5)]">
                <span className="grid size-12 shrink-0 place-items-center rounded-xl bg-navy/5 text-navy transition duration-300 group-hover:bg-navy group-hover:text-amber"><Icon size={22} strokeWidth={1.75} /></span>
                <span className="font-medium leading-snug text-navy">{t}</span>
              </li>
            </Reveal>
          );
        })}
      </ul>
    </section>
  );
}
