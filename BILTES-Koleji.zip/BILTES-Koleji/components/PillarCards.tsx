"use client";
import { motion, useMotionTemplate, useMotionValue, useReducedMotion, useSpring, useTransform } from "motion/react";
import type { MouseEvent, ReactNode } from "react";

/** Bilim, Teknoloji, Eğitim, Sanat için animasyonlu çizgi ikonları (40x40). */
const ICONS: ReactNode[] = [
  <>
    <g className="ico-spin"><ellipse cx="20" cy="20" rx="16" ry="6" /><ellipse cx="20" cy="20" rx="16" ry="6" transform="rotate(60 20 20)" /><ellipse cx="20" cy="20" rx="16" ry="6" transform="rotate(120 20 20)" /></g>
    <circle className="ico-pulse" cx="20" cy="20" r="2.6" fill="currentColor" stroke="none" />
  </>,
  <>
    <rect x="11" y="11" width="18" height="18" rx="2.5" />
    <rect className="ico-pulse" x="16" y="16" width="8" height="8" rx="1" fill="currentColor" stroke="none" />
    <path className="ico-dash" d="M16 4v7M24 4v7M16 29v7M24 29v7M4 16h7M4 24h7M29 16h7M29 24h7" />
  </>,
  <>
    <path d="M20 14c-3-2.5-8-3.3-14-2.3v18c6-1 11-.2 14 2.3 3-2.5 8-3.3 14-2.3v-18c-6-1-11-.2-14 2.3ZM20 14v18" />
    <path className="ico-twinkle" d="M20 1.5v5M17.5 4h5" />
  </>,
  <>
    <path d="M20 5C11 5 5 11 5 19s6 15 14 15c3 0 4-2 3-4s0-4 3-4h5c4 0 6-3 6-6C36 10 29 5 20 5Z" />
    <circle className="ico-dot" cx="13" cy="17" r="2" fill="currentColor" stroke="none" />
    <circle className="ico-dot" style={{ animationDelay: ".6s" }} cx="19" cy="12" r="2" fill="currentColor" stroke="none" />
    <circle className="ico-dot" style={{ animationDelay: "1.2s" }} cx="26" cy="14" r="2" fill="currentColor" stroke="none" />
    <circle className="ico-dot" style={{ animationDelay: "1.8s" }} cx="12" cy="25" r="2" fill="currentColor" stroke="none" />
  </>,
];

function Card({ i, title, text }: { i: number; title: string; text: string }) {
  const reduce = useReducedMotion();
  const mx = useMotionValue(0);
  const my = useMotionValue(0);
  const rx = useSpring(useTransform(my, [-0.5, 0.5], [7, -7]), { stiffness: 200, damping: 20 });
  const ry = useSpring(useTransform(mx, [-0.5, 0.5], [-9, 9]), { stiffness: 200, damping: 20 });
  const gx = useMotionValue(50);
  const gy = useMotionValue(0);
  const glow = useMotionTemplate`radial-gradient(260px circle at ${gx}% ${gy}%, rgba(255,255,255,0.16), transparent 70%)`;
  const move = (e: MouseEvent<HTMLLIElement>) => {
    if (reduce) return;
    const r = e.currentTarget.getBoundingClientRect();
    gx.set(((e.clientX - r.left) / r.width) * 100);
    gy.set(((e.clientY - r.top) / r.height) * 100);
    mx.set((e.clientX - r.left) / r.width - 0.5);
    my.set((e.clientY - r.top) / r.height - 0.5);
  };
  const leave = () => { mx.set(0); my.set(0); };
  return (
    <motion.li
      className="h-full [perspective:900px]"
      initial={reduce ? false : { opacity: 0, y: 48 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-40px" }}
      transition={{ duration: 0.8, delay: i * 0.12, ease: [0.22, 1, 0.36, 1] }}
      onMouseMove={move}
      onMouseLeave={leave}
    >
      <motion.div style={reduce ? undefined : { rotateX: rx, rotateY: ry }} className="group relative h-full overflow-hidden rounded-3xl border border-navy/10 bg-white p-8 shadow-[0_10px_40px_-18px_rgba(27,58,120,0.35)] transition-shadow duration-500 hover:shadow-[0_30px_60px_-20px_rgba(27,58,120,0.55)] md:p-9">
        <span aria-hidden className="absolute inset-0 origin-bottom scale-y-0 bg-navy transition-transform duration-700 ease-out group-hover:scale-y-100" />
        <span aria-hidden className="absolute right-0 top-0 h-32 w-32 opacity-60 transition-opacity duration-500 group-hover:opacity-100 [background-image:radial-gradient(currentColor_1.4px,transparent_1.5px)] [background-size:14px_14px] [mask-image:linear-gradient(225deg,#000,transparent_70%)] text-navy/25 group-hover:text-white/30" />
        <span aria-hidden className="absolute inset-x-0 top-0 h-1 origin-left scale-x-0 bg-gradient-to-r from-amber via-teal to-amber transition-transform duration-700 group-hover:scale-x-100" />
        <motion.span aria-hidden style={{ background: glow }} className="pointer-events-none absolute inset-0 opacity-0 transition-opacity duration-500 group-hover:opacity-100" />
        <span aria-hidden className="pointer-events-none absolute right-5 top-3 select-none font-display text-7xl font-extrabold leading-none text-navy/[0.07] transition-colors duration-500 group-hover:text-white/10">0{i + 1}</span>
        <div className="relative">
          <div className="relative grid size-24 place-items-center">
            <svg aria-hidden viewBox="0 0 100 100" className="ring-spin absolute inset-0 text-navy/25 transition-colors duration-500 group-hover:text-amber"><circle cx="50" cy="50" r="48" fill="none" stroke="currentColor" strokeWidth="1.5" strokeDasharray="3 7" strokeLinecap="round" /></svg>
            <span className="grid size-16 place-items-center rounded-full bg-navy/5 text-navy transition-all duration-500 group-hover:scale-110 group-hover:bg-white/10 group-hover:text-amber">
              <svg aria-hidden viewBox="0 0 40 40" className="size-10" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round">{ICONS[i % 4]}</svg>
            </span>
          </div>
          <h3 className="mt-7 text-2xl font-extrabold tracking-wide text-navy transition-colors duration-500 group-hover:text-white">{title}</h3>
          <span aria-hidden className="mt-3 block h-[3px] w-10 rounded bg-amber transition-all duration-500 group-hover:w-24" />
          <p className="mt-4 leading-7 text-ink/70 transition-colors duration-500 group-hover:text-white/85">{text}</p>
        </div>
      </motion.div>
    </motion.li>
  );
}

export function PillarCards({ items }: { items: { title: string; text: string }[] }) {
  return (
    <ul className="wrap grid auto-rows-fr gap-5 sm:grid-cols-2 lg:grid-cols-4 lg:gap-6">
      {items.map((p, i) => <Card key={i} i={i} title={p.title} text={p.text} />)}
    </ul>
  );
}
