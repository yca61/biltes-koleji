"use client";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { useEffect, useState, type ReactNode } from "react";
import { LayoutDashboard, FileText, Building2, GraduationCap, Newspaper, CalendarDays, Trophy, Users2, Quote, Image as Img, Inbox, Menu as MenuIcon, Settings, Shield, ScrollText, Home, Layers, ArrowRightLeft, LogOut, ExternalLink, X, Bell, Tags, SearchCheck } from "lucide-react";

const NAV = [
  { href: "/admin", label: "Panel", icon: LayoutDashboard },
  { href: "/admin/anasayfa", label: "Anasayfa Oluşturucu", icon: Home, group: "İçerik" },
  { href: "/admin/r/hero", label: "Hero Slaytları", icon: Layers },
  { href: "/admin/r/pages", label: "Sayfalar", icon: FileText },
  { href: "/admin/r/campuses", label: "Kampüsler", icon: Building2 },
  { href: "/admin/r/programs", label: "Eğitim Programları", icon: GraduationCap },
  { href: "/admin/r/news", label: "Haber & Duyurular", icon: Newspaper },
  { href: "/admin/r/categories", label: "Haber Kategorileri", icon: Tags },
  { href: "/admin/r/events", label: "Etkinlikler", icon: CalendarDays },
  { href: "/admin/r/achievements", label: "Başarılar", icon: Trophy },
  { href: "/admin/r/clubs", label: "Kulüp & Atölyeler", icon: Users2 },
  { href: "/admin/r/testimonials", label: "Veli Görüşleri", icon: Quote },
  { href: "/admin/medya", label: "Medya Kitaplığı", icon: Img, group: "Kaynaklar" },
  { href: "/admin/menuler", label: "Menüler", icon: MenuIcon },
  { href: "/admin/r/redirects", label: "Yönlendirmeler", icon: ArrowRightLeft },
  { href: "/admin/leads", label: "Başvurular (CRM)", icon: Inbox, group: "Kayıt" },
  { href: "/admin/seo", label: "Google SEO", icon: SearchCheck, group: "Sistem" },
  { href: "/admin/ayarlar", label: "Site Ayarları", icon: Settings },
  { href: "/admin/kullanicilar", label: "Kullanıcılar", icon: Shield },
  { href: "/admin/denetim", label: "Denetim Kayıtları", icon: ScrollText },
];

const TITLES: [string, string][] = [["/admin/anasayfa", "Anasayfa Oluşturucu"], ["/admin/medya", "Medya Kitaplığı"], ["/admin/menuler", "Menüler"], ["/admin/leads", "Başvurular"], ["/admin/ayarlar", "Site Ayarları"], ["/admin/kullanicilar", "Kullanıcılar"], ["/admin/denetim", "Denetim Kayıtları"]];

type Props = { allowed: string[]; badges: Record<string, number>; user: { name: string; role: string }; logoUrl: string; logout: () => Promise<void>; children: ReactNode };

/** Yönetim paneli kabuğu: aktif sayfa vurgulu yan menü, sayaç rozetleri, mobil çekmece ve üst çubuk. */
export function AdminShell({ allowed, badges, user, logoUrl, logout, children }: Props) {
  const path = usePathname();
  const [open, setOpen] = useState(false);
  useEffect(() => setOpen(false), [path]);
  useEffect(() => { document.body.style.overflow = open ? "hidden" : ""; }, [open]);
  const items = NAV.filter((n) => allowed.includes(n.href));
  const isActive = (href: string) => (href === "/admin" ? path === "/admin" : path === href || path.startsWith(href + "/"));
  const resTitle = items.find((n) => isActive(n.href) && n.href !== "/admin")?.label ?? TITLES.find(([p]) => path.startsWith(p))?.[1] ?? "Panel";
  const initials = user.name.split(/\s+/).map((p) => p[0]).slice(0, 2).join("").toLocaleUpperCase("tr");
  const newLeads = badges["/admin/leads"] ?? 0;

  const Nav = (
    <nav aria-label="Yönetim menüsü" className="space-y-0.5 px-3 pb-8">
      {items.map((n) => {
        const active = isActive(n.href);
        return (
          <div key={n.href}>
            {n.group && <p className="mb-1 mt-6 px-3 text-[10px] font-semibold uppercase tracking-widest text-white/40">{n.group}</p>}
            <Link href={n.href} aria-current={active ? "page" : undefined} className={`group relative flex items-center gap-3 whitespace-nowrap rounded-lg px-3 py-2 text-sm transition ${active ? "bg-white/15 font-semibold text-white" : "text-white/75 hover:bg-white/10 hover:text-white"}`}>
              {active && <span aria-hidden className="absolute -left-3 top-1.5 h-6 w-1 rounded-r bg-amber" />}
              <n.icon size={17} className={active ? "text-amber" : "text-white/60 group-hover:text-white"} />
              <span className="flex-1">{n.label}</span>
              {!!badges[n.href] && <span className="rounded-full bg-amber px-2 py-0.5 text-[11px] font-bold text-navy">{badges[n.href]}</span>}
            </Link>
          </div>
        );
      })}
    </nav>
  );
  const Brand = (
    <Link href="/admin" className="flex items-center gap-3 p-5">
      {logoUrl ? <img src={logoUrl} alt="" className="h-10 w-10 rounded-lg bg-white object-contain p-0.5" /> : null}
      <span className="font-display text-xl font-extrabold leading-none">BİLTES<span className="mt-1 block text-[10px] tracking-[.3em] text-amber">YÖNETİM</span></span>
    </Link>
  );

  return (
    <div className="min-h-screen bg-mist lg:flex">
      <aside className="hidden bg-navy text-white lg:sticky lg:top-0 lg:block lg:h-screen lg:w-64 lg:shrink-0 lg:overflow-y-auto">{Brand}{Nav}</aside>
      {open && (
        <div className="fixed inset-0 z-50 lg:hidden" role="dialog" aria-modal="true">
          <div className="absolute inset-0 bg-black/50" onClick={() => setOpen(false)} />
          <aside className="absolute inset-y-0 left-0 w-72 max-w-[85%] overflow-y-auto bg-navy text-white shadow-2xl">
            <button onClick={() => setOpen(false)} aria-label="Menüyü kapat" className="absolute right-3 top-4 grid size-9 place-items-center rounded-full bg-white/10"><X size={18} /></button>
            {Brand}{Nav}
          </aside>
        </div>
      )}
      <div className="min-w-0 flex-1">
        <header className="sticky top-0 z-30 flex h-16 items-center gap-3 border-b border-navy/10 bg-white/90 px-4 backdrop-blur lg:px-8">
          <button onClick={() => setOpen(true)} aria-label="Menüyü aç" className="grid size-10 place-items-center rounded-lg border border-navy/15 text-navy lg:hidden"><MenuIcon size={20} /></button>
          <h2 className="truncate font-display text-lg font-bold text-navy">{resTitle}</h2>
          <div className="ml-auto flex items-center gap-2 sm:gap-4">
            <a href="/tr" target="_blank" rel="noopener" className="hidden items-center gap-2 rounded-full border border-navy/15 px-4 py-2 text-sm font-medium text-navy transition hover:bg-navy hover:text-white sm:inline-flex"><ExternalLink size={14} />Siteyi görüntüle</a>
            {allowed.includes("/admin/leads") && (
              <Link href="/admin/leads?status=NEW" aria-label={`${newLeads} yeni başvuru`} className="relative grid size-10 place-items-center rounded-full border border-navy/15 text-navy transition hover:bg-mist">
                <Bell size={17} />{newLeads > 0 && <span className="absolute -right-1 -top-1 grid min-w-5 place-items-center rounded-full bg-[#D93A17] px-1 text-[11px] font-bold text-white">{newLeads}</span>}
              </Link>
            )}
            <div className="flex items-center gap-3 border-l border-navy/10 pl-3 sm:pl-4">
              <span className="grid size-10 place-items-center rounded-full bg-navy text-sm font-bold text-white" aria-hidden>{initials}</span>
              <span className="hidden leading-tight md:block"><b className="block text-sm text-navy">{user.name}</b><span className="text-xs text-ink/55">{user.role}</span></span>
              <form action={logout}><button className="grid size-10 place-items-center rounded-full text-ink/60 transition hover:bg-mist hover:text-navy" aria-label="Çıkış"><LogOut size={17} /></button></form>
            </div>
          </div>
        </header>
        <main className="p-4 lg:p-8">{children}</main>
      </div>
    </div>
  );
}
